# postgrest-apikit/sass/etc

This folder contains miscellaneous SASS files. Unlike `"postgrest-apikit/sass/etc"`, these files
need to be used explicitly.
